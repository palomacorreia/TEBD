package com.example.sc_sac.bean;

public abstract class Artigo {
    private Long    artigoId;
    private String  artigoNome;
    private String  artigoResumo;
    private String  artigoArquivo;
    private Boolean artigoConfirmaSubmissao;
    private Integer artigoQuantidadeRevisores;
    private Float   artigoMedia;

    public Artigo() {
    }

    public Long getArtigoId() {
        return artigoId;
    }

    public void setArtigoId(Long artigoId) {
        this.artigoId = artigoId;
    }

    public String getArtigoNome() {
        return artigoNome;
    }

    public void setArtigoNome(String artigoNome) {
        this.artigoNome = artigoNome;
    }

    public String getArtigoResumo() {
        return artigoResumo;
    }

    public void setArtigoResumo(String artigoResumo) {
        this.artigoResumo = artigoResumo;
    }

    public String getArtigoArquivo() {
        return artigoArquivo;
    }

    public void setArtigoArquivo(String artigoArquivo) {
        this.artigoArquivo = artigoArquivo;
    }

    public Boolean getArtigoConfirmaSubmissao() {
        return artigoConfirmaSubmissao;
    }

    public void setArtigoConfirmaSubmissao(Boolean artigoConfirmaSubmissao) {
        this.artigoConfirmaSubmissao = artigoConfirmaSubmissao;
    }

    public Integer getArtigoQuantidadeRevisores() {
        return artigoQuantidadeRevisores;
    }

    public void setArtigoQuantidadeRevisores(Integer artigoQuantidadeRevisores) {
        this.artigoQuantidadeRevisores = artigoQuantidadeRevisores;
    }

    public Float getArtigoMedia() {
        return artigoMedia;
    }

    public void setArtigoMedia(Float artigoMedia) {
        this.artigoMedia = artigoMedia;
    }
}
