package com.example.sc_sac.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import java.util.List;

public class QuentinhaDataSource {
    private SQLiteDatabase database;
    private MySQLiteHelper dbHelper;
    private int openCount = 0;

    public QuentinhaDataSource(Context context) {
        dbHelper = new MySQLiteHelper(context);
    }

    public void openDatabase() {
        if(openCount <= 0) {
            synchronized (QuentinhaDataSource.class) {
                try {
                    database = dbHelper.getWritableDatabase();
                    openCount = 1;
                } catch (SQLiteException ex) {
                    ex.printStackTrace();
                }
            }
        } else {
            openCount++;
        }
    }

    public void closeDatabase() {
        if(openCount > 1) {
            openCount--;
        } else {
            openCount = 0;
            synchronized (QuentinhaDataSource.class) {
                if (database != null && database.isOpen()) {
                    database.close();
                }
            }
        }
    }

    public boolean save(DatabaseBean bean) {
        openDatabase();
        try {
            return bean.save(database);
        } finally {
            closeDatabase();
        }
    }

//    public Vendedor newVendedor() {
//        return new VendedorTable(null);
//    }
//
//    public Pratos newPrato() {
//        return new PratoTable(null);
//    }
//
//    public Vendedor getVendedor(){
//        openDatabase();
//        try {
//            return VendedorTable.getVendedor(database);
//        }finally {
//            closeDatabase();
//        }
//    }
//
//    public List<Pratos> getPratos(){
//        openDatabase();
//        try{
//            return PratoTable.getPratos(database);
//        }finally {
//            closeDatabase();
//        }
//    }
//    public void deleteVendedores(){
//        openDatabase();
//        try {
//            VendedorTable.deleteVendedores(database);
//        }finally {
//            closeDatabase();
//        }
//    }
//
//    public void deletePratos(){
//        openDatabase();
//        try {
//            PratoTable.deletePratos(database);
//        }finally {
//            closeDatabase();
//        }
//    }
//
//    public void deletePratoByUuid(String uuidPrato){
//        openDatabase();
//        try {
//            PratoTable.deletePratoByUuid(database, uuidPrato);
//        }finally {
//            closeDatabase();
//        }
//    }
}
