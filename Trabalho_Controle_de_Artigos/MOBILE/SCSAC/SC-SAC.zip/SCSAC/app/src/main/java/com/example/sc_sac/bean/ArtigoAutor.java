package com.example.sc_sac.bean;

public abstract class ArtigoAutor {
    private Long artigoAutorId;
    private Long usuarioId;
    private Long artigoId;

    public ArtigoAutor() {}

    public Long getArtigoAutorId() {
        return artigoAutorId;
    }

    public void setArtigoAutorId(Long artigoAutorId) {
        this.artigoAutorId = artigoAutorId;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public Long getArtigoId() {
        return artigoId;
    }

    public void setArtigoId(Long artigoId) {
        this.artigoId = artigoId;
    }
}
